# linear_search.py
arr = list(map(int, input("Enter elements of the list: ").split()))
key = int(input("Enter the element to search: "))

found = False

for i in range(len(arr)):
    if arr[i] == key:
        print("Element found at index:", i)
        found = True
        break

if not found:
    print("Element not found in the list")
