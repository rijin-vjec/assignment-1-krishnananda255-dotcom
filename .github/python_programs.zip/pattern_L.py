# pattern_L.py
rows = 6  # height of L

for i in range(rows):
    if i == rows - 1:
        print("* " * 5)  # bottom horizontal line
    else:
        print("*")       # vertical line
